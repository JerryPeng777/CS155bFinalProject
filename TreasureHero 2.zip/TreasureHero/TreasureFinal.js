//Let's begin!

//First, we need to declare some variables
// in the animation code
var scene, renderer;  // all threejs programs need these
var camera, avatarCam, edgeCam;  // we have two cameras in the main scene
var avatar; //This is the race car we control to play
var land;

var matrix = new THREE.Matrix4();

var worldWidth = 128, worldDepth = 128, worldHalfWidth = worldWidth / 2, worldHalfDepth = worldDepth / 2, data = generateHeight( worldWidth, worldDepth );
var clock = new THREE.Clock();

var obstruction1;

var controls =
     {fwd:false, bwd:false, left:false, right:false,
      speed:10, reset:false, go:false, back:false, goLeft:false, goRight:false,
      camera:camera}

var gameState =
     {score:0, health:3, scene:'main', camera:'none' }



// Here is the main game control
init(); //
initControls();
animate();  // start the animation loop!


/**
  To initialize the scene, we initialize each of its components
*/
function init(){
    initPhysijs();
    scene = initScene();
    initRenderer();
    createMainScene();
}

//------------------------------------------------------------------------------

// This part creats some very basic elements of the game
// When you add something in this program, remeber to add it in this main method

function createMainScene(){
  // setup lighting
  var light1 = createPointLight();
  light1.position.set(0,200,20);
  scene.add(light1);
  var light0 = new THREE.AmbientLight( 0xffffff,0.25);
  scene.add(light0);


  // create main camera
  camera = new THREE.PerspectiveCamera( 90, window.innerWidth / window.innerHeight, 0.1, 1000 );
  camera.position.set(0,150,0);
  camera.lookAt(0,0,0);
  gameState.camera = camera;

  // create the ground and the skybox
  var ground = createGround('land.png');
  scene.add(ground);
  var skybox = createSkyBox('sky.jpg',1);
  scene.add(skybox);

  edgeCam = new THREE.PerspectiveCamera( 60, window.innerWidth / window.innerHeight, 0.1, 1000 );
  edgeCam.position.set(20,20,10);

  //create the avatar as the replacement of the race car
  avatarCam = new THREE.PerspectiveCamera( 60, window.innerWidth / window.innerHeight, 0.1, 1000 );
  avatar = createAvatar();
  avatar.position.set(-66,1,0);
  avatar.translateY(20);
  avatarCam.translateY(-4);
  avatarCam.translateZ(3);
  scene.add(avatar);
  gameState.camera = avatarCam;

  createLand();

  var addLand = new THREE.PlaneGeometry(100,100);

  var dummy = new THREE.Mesh();
	for ( var z = 0; z < worldDepth; z ++ ) {
		for ( var x = 0; x < worldWidth; x ++ ) {
			var h = getY( x, z );
			matrix.makeTranslation(
				x * 100 - worldHalfWidth * 100,
				h * 100,
				z * 100 - worldHalfDepth * 100
			);
			var px = getY( x + 1, z );
			var nx = getY( x - 1, z );
			var pz = getY( x, z + 1 );
			var nz = getY( x, z - 1 );
			var pxpz = getY( x + 1, z + 1 );
			var nxpz = getY( x - 1, z + 1 );
			var pxnz = getY( x + 1, z - 1 );
			var nxnz = getY( x - 1, z - 1 );
			var a = nx > h || nz > h || nxnz > h ? 0 : 1;
			var b = nx > h || pz > h || nxpz > h ? 0 : 1;
			var c = px > h || pz > h || pxpz > h ? 0 : 1;
			var d = px > h || nz > h || pxnz > h ? 0 : 1;
			if ( a + c > b + d ) {
				geometry.merge( addLand, matrix );
			} else {
				geometry.merge( addLand, matrix );
			}
			if ( ( px != h && px != h + 1 ) || x == 0 ) {
				geometry.merge( addLand, matrix );
			}
			if ( ( nx != h && nx != h + 1 ) || x == worldWidth - 1 ) {
				geometry.merge( addLand, matrix );
			}
			if ( ( pz != h && pz != h + 1 ) || z == worldDepth - 1 ) {
				geometry.merge( addLand, matrix );
			}
			if ( ( nz != h && nz != h + 1 ) || z == 0 ) {
				geometry.merge( addLand, matrix );
			}
		}
	}

  var geometry = new THREE.PlaneGeometry( 100, 100 );
	var texture = new THREE.TextureLoader().load( '../textures/minecraft/atlas.png' );
	texture.magFilter = THREE.NearestFilter;
	texture.minFilter = THREE.LinearMipMapLinearFilter;
	var material1 = new THREE.MeshLambertMaterial( { map: texture, vertexColors: THREE.VertexColors } );
	var pmaterial1 = new Physijs.createMaterial(material1,0.9,0.5);
	var mesh1 = new Physijs.ConvexMesh( geometry, pmaterial1, 0 );
	scene.add( mesh1 );






}

//------------------------------------------------------------------------------
// This part is the default part. All the codes need this part

// DO NOT CHANGE ANYTHING IN THIS PART!!!!

/* We don't do much here, but we could do more!
*/
function initScene(){
  //scene = new THREE.Scene();
  var scene = new Physijs.Scene();
  return scene;
}
// initialize the physijs
function initPhysijs(){
  Physijs.scripts.worker = '/js/physijs_worker.js';
  Physijs.scripts.ammo = '/js/ammo.js';
}
/*
  The renderer needs a size and the actual canvas we draw on
  needs to be added to the body of the webpage. We also specify
  that the renderer will be computing soft shadows
*/
function initRenderer(){
  renderer = new THREE.WebGLRenderer();
  renderer.setSize( window.innerWidth, window.innerHeight-50 );
  document.body.appendChild( renderer.domElement );
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
}

function createPointLight(){
  var light;
  light = new THREE.PointLight( 0xffffff);
  light.castShadow = true;
  //Set up shadow properties for the light
  light.shadow.mapSize.width = 2048;  // default
  light.shadow.mapSize.height = 2048; // default
  light.shadow.camera.near = 0.5;       // default
  light.shadow.camera.far = 500      // default
  return light;
}

function createGround(){
  // creating a textured plane which receives shadows
  var geometry = new THREE.PlaneGeometry( 500, 500, 500 );
  var texture = new THREE.TextureLoader().load( '../textures/minecraft/atlas.png' );
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set( 15, 15 );
  var material = new THREE.MeshLambertMaterial( { color: 0xffffff,  map: texture ,side:THREE.DoubleSide} );
  var pmaterial = new Physijs.createMaterial(material,0.9,0.05);
  //var mesh = new THREE.Mesh( geometry, material );
  var mesh = new Physijs.BoxMesh( geometry, pmaterial, 0 );
  mesh.receiveShadow = true;
  mesh.rotateX(Math.PI/2);
  return mesh
  // we need to rotate the mesh 90 degrees to make it horizontal not vertical
}

function createSkyBox(image,k){
  // creating a textured plane which receives shadows
  var geometry = new THREE.SphereGeometry( 160, 160, 160 );
  var texture = new THREE.TextureLoader().load( '../images/'+image );
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set( k, k );
  var material = new THREE.MeshLambertMaterial( { color: 0xffffff,  map: texture ,side:THREE.DoubleSide} );
  //var pmaterial = new Physijs.createMaterial(material,0.9,0.5);
  //var mesh = new THREE.Mesh( geometry, material );
  var mesh = new THREE.Mesh( geometry, material, 0 );
  mesh.receiveShadow = false;
  return mesh
  // we need to rotate the mesh 90 degrees to make it horizontal not vertical
}

//------------------------------------------------------------------------------
// Now let's creat the race track and the background
// This part builds some elements of the game


function createAvatar(other_object){
  //var geometry = new THREE.SphereGeometry( 4, 20, 20);
  var geometry = new THREE.BoxGeometry( 5, 5, 6);
  var material = new THREE.MeshLambertMaterial( { color: 0xffff00} );
  var pmaterial = new Physijs.createMaterial(material,0.9,0.5);
  //var mesh = new THREE.Mesh( geometry, material );
  var mesh = new Physijs.BoxMesh( geometry, pmaterial );
  mesh.setDamping(0.1,0.1);
  mesh.castShadow = true;
  avatarCam.position.set(0,4,0);
  avatarCam.lookAt(0,4,10);
  mesh.add(avatarCam);
  return mesh;
}

function randN(n){
  return Math.random()*n;
}

function generateHeight( width, height ) {
	var data = [], perlin = new ImprovedNoise(),
	size = width * height, quality = 2, z = Math.random() * 100;
	for ( var j = 0; j < 4; j ++ ) {
		if ( j === 0 ) for ( var i = 0; i < size; i ++ ) data[ i ] = 0;
		for ( var i = 0; i < size; i ++ ) {
			var x = i % width, y = ( i / width ) | 0;
			data[ i ] += perlin.noise( x / quality, y / quality, z ) * quality;
		}
		quality *= 4;
	}
	return data;
}

function createLand(){
  var numLand = 50;
  for(var i = 1; i < numLand; i++){
    land = createBoxMesh();
    land.position.set(randN(20)+15,30,randN(20)+15);
    scene.add(land);
  }
}

function createBoxMesh(){
  var geometry = new THREE.BoxGeometry( 1, 1, 1);
  var texture = new THREE.TextureLoader().load( '../textures/minecraft/atlas.png' );
	texture.magFilter = THREE.NearestFilter;
	texture.minFilter = THREE.LinearMipMapLinearFilter;
  var material1 = new THREE.MeshLambertMaterial( { map: texture, vertexColors: THREE.VertexColors } );
	var pmaterial1 = new Physijs.createMaterial(material1,0.9,0.5);
	var mesh1 = new Physijs.ConvexMesh( geometry, pmaterial1, 0 );
	return mesh1;
}

function getY( x, z ) {
	return ( data[ x + z * worldWidth ] * 0.2 ) | 0;
}


//------------------------------------------------------------------------------
// This part allows the user to control the race car via keyboard

var clock;
function initControls(){
  // here is where we create the eventListeners to respond to operations
    //create a clock for the time-based animation ...
    clock = new THREE.Clock();
    clock.start();

    window.addEventListener( 'keydown', keydown);
    window.addEventListener( 'keyup',   keyup );
}

function keydown(event){
  console.log("Keydown: '"+event.key+"'");
  //console.dir(event);
  // first we handle the "play again" key in the "youwon" scene
  if (gameState.scene == 'youwon' && event.key=='r') {
    gameState.scene = 'main';
    gameState.score = 0;
    addBalls();
    return;
  }

  if(gameState.scene == 'initialPicture' && event.key=='p'){
    gameState.scene = 'main';
    gameState.score = 0;
    return;
  }

  if(gameState.scene=='youlose'&&event.key=='r'){
    gameState.scene = 'main';
    gameState.score = 0;
    return;
  }

  // this is the regular scene
  switch (event.key){
    // change the way the avatar is moving
    case "w": controls.fwd = true;  break;
    case "s": controls.bwd = true; break;
    case "a": controls.left = true; break;
    case "d": controls.right = true; break;
    case "r": controls.up = true; break;
    case "f": controls.down = true; break;
    case "m": controls.speed = 30; break;
    case "h": controls.reset = true; break;
    case "q": controls.rotateToLeft = true; break;
    case "e": controls.rotateToRight = true; break;
    // switch cameras
    case "1": gameState.camera = camera; break;
    case "2": gameState.camera = avatarCam; break;
    case "3": gameState.camera = edgeCam; break;
    // move the camera around, relative to the avatar
    case "ArrowLeft": avatarCam.translateY(1);break;
    case "ArrowRight": avatarCam.translateY(-1);break;
    case "ArrowUp": avatarCam.translateZ(-1);break;
    case "ArrowDown": avatarCam.translateZ(1);break;

  }
}

function keyup(event){
  //console.log("Keydown:"+event.key);
  //console.dir(event);
  switch (event.key){
    case "w": controls.fwd   = false;  break;
    case "s": controls.bwd   = false; break;
    case "a": controls.left  = false; break;
    case "d": controls.right = false; break;
    case "r": controls.up    = false; break;
    case "f": controls.down  = false; break;
    case "m": controls.speed = 10; break;
    case "h": controls.reset = false; break;
    case "q": controls.rotateToLeft = false; break;
    case "e": controls.rotateToRight = false; break;

  }
}

function updateAvatar(){
  "change the avatar's linear or angular velocity based on controls state (set by WSAD key presses)"

  var forward = avatar.getWorldDirection();
  var goLeft = avatar.getWorldDirection();
  // When the user press forward & backward
  if (controls.fwd){
    avatar.setLinearVelocity(forward.multiplyScalar(controls.speed));
  } else if (controls.bwd){
    avatar.setLinearVelocity(forward.multiplyScalar(-controls.speed));
  } else {
    var velocity = avatar.getLinearVelocity();
    velocity.x=velocity.z=0;
    avatar.setLinearVelocity(velocity); //stop the xz motion
  }
  //When the user press the left & right
  if (controls.left){
    avatar.setAngularVelocity(new THREE.Vector3(0,controls.speed*0.1,0));
  } else if (controls.right){
    avatar.setAngularVelocity(new THREE.Vector3(0,-controls.speed*0.1,0));
  }
  //When the user tryies to move the camera
  if(controls.rotateToLeft){
    avatarCam.rotateY(0.01);
  }else if(controls.rotateToRight){
    avatarCam.rotateY(-0.01);
  }
  //Whehn the user wants to reset the game
  if (controls.reset){
    avatar.__dirtyPosition = true;
    avatar.position.set(40,10,40);
  }

}

//------------------------------------------------------------------------------

function animate() {
  var counter = 0;
  requestAnimationFrame( animate );


  switch(gameState.scene) {
/*
    case "youwon":
      endText.rotateY(0.005);
      renderer.render( endScene, endCamera );
      break;
*/
    case "main":
      updateAvatar();
      scene.simulate();
      if (gameState.camera!= 'none'){
        renderer.render( scene, gameState.camera );
      }
      break;

    default:
      console.log("don't know the scene "+gameState.scene);
  }
  //draw heads up display ..
  var info = document.getElementById("info");
  info.innerHTML='<div style="font-size:24pt">Score: ' + gameState.score + '</div>';
}
