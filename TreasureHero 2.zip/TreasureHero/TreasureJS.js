/*if ( ! Detector.webgl ) {
				Detector.addGetWebGLMessage();
				document.getElementById( 'container' ).innerHTML = '<div style="font-size:24pt">Score: ' + gameState.score + '</div>';
			}
*/
var container, stats;
var closebox;
var camera, controls, scene, renderer,edgeCam;
var mesh, test;
var worldWidth = 128, worldDepth = 128, worldHalfWidth = worldWidth / 2, worldHalfDepth = worldDepth / 2, data = generateHeight( worldWidth, worldDepth );
var clock = new THREE.Clock();
var raycaster = new THREE.Raycaster();
var mouse, raycaster, isShiftDown = false;
var objects = [];
var ball;
var endScene, endCamera, endText, loseText, loseScene, initialPicture, initialText;

var controls =
		 {fwd:false, bwd:false, left:false, right:false,
			speed:10, fly:false, reset:false, rotateToLeft:false, rotateToRight:false, launch:false,
			avatarCamAngle:Math.PI};
var gameState =
     {score:0, health:3, scene:'main', camera:'none' };


init();
initControls();
animate();
//initOBJbox();

function init(){
  initPhysijs();
  initRenderer();
  scene = initScene();
	createEndScene();
  createMainScene();
}

function createEndScene(){
	endScene = initScene();
	loseScene = initScene();
	initialPicture = initScene();

	endText = createSkyBox('youwon.png',10);
	//loseText = createSkyBox('youlose.png',10);
	//initialText = createSkyBox('initialPicture.png',10);
	//endText.rotateX(Math.PI);
	endScene.add(endText);
	//loseScene.add(loseText);
	//initialPicture.add(initialText);
	var light1 = createPointLight();
	light1.position.set(0,200,20);
	endScene.add(light1);/*
	var light2 = createPointLight();
	light1.position.set(0,200,20);
	loseScene.add(light2);
	var light3 = createPointLight();
	light1.position.set(0,200,20);
	initialPicture.add(light3);*/
	endCamera = new THREE.PerspectiveCamera( 90, window.innerWidth / window.innerHeight, 0.1, 1000 );
	endCamera.position.set(0,50,1);
	endCamera.lookAt(0,0,0);

}

function createPointLight(){
	var light;
	light = new THREE.PointLight( 0xffffff);
	light.castShadow = true;
	//Set up shadow properties for the light
	light.shadow.mapSize.width = 2048;  // default
	light.shadow.mapSize.height = 2048; // default
	light.shadow.camera.near = 0.5;       // default
	light.shadow.camera.far = 500      // default
	return light;
}

function initPhysijs(){
  Physijs.scripts.worker = '/js/physijs_worker.js';
  Physijs.scripts.ammo = '/js/ammo.js';
}
/*
  The renderer needs a size and the actual canvas we draw on
  needs to be added to the body of the webpage. We also specify
  that the renderer will be computing soft shadows
*/
function initRenderer(){
  renderer = new THREE.WebGLRenderer();
	renderer.setPixelRatio( window.devicePixelRatio );
	renderer.setSize( window.innerWidth, window.innerHeight );
}

function createSkyBox(image,k){
	// creating a textured plane which receives shadows
	var geometry = new THREE.SphereGeometry( 80, 80, 80 );
	var texture = new THREE.TextureLoader().load( '../images/'+image );
	texture.wrapS = THREE.RepeatWrapping;
	texture.wrapT = THREE.RepeatWrapping;
	texture.repeat.set( k, k );
	var material = new THREE.MeshLambertMaterial( { color: 0xffffff,  map: texture ,side:THREE.DoubleSide} );
	//var pmaterial = new Physijs.createMaterial(material,0.9,0.5);
	//var mesh = new THREE.Mesh( geometry, material );
	var mesh = new THREE.Mesh( geometry, material, 0 );
	mesh.receiveShadow = false;
	return mesh
	// we need to rotate the mesh 90 degrees to make it horizontal not vertical
}




function initOBJbox(){
  var loader = new THREE.OBJLoader();
  loader.load("closebox.obj",
     function ( objbox) {
      console.log("loading objbox file");
		//	var geometry = objbox;
		//	var material = new THREE.MeshLambertMaterial( { color: 0xff0000 } );
			//geometry.scale.set(0.5,0.5,0.5);
		//	objbox = new Physijs.BoxMesh( geometry, material,0 );
      objbox.scale.x=1;
      objbox.scale.y=1;
      objbox.scale.z=1;
      objbox.position.y = getY( worldHalfWidth, worldHalfDepth ) * 100 + 100;
      //objbox.position.z = 0;
      //obj.material.color.setHex(0xff0000);

      objbox.rotation.x = Math.PI /-2;


      scene.add(objbox);
      objbox.castShadow = true;

      //
		},

     function(xhr){
      console.log( (xhr.loaded / xhr.total * 100) + '% loaded' );},

     function(err){
      console.log("error in loading: "+err);}
    )
 }

/*
 function initBoxOBJ(){
	 //load the monkey avatar into the scene, and add a Physics mesh and camera
	 var loader = new THREE.OBJLoader();
	 loader.load("closebox.obj",
				 function ( geometry, materials ) {
					 console.log("loading closebox");
					 var material = //materials[ 0 ];
					 new THREE.MeshLambertMaterial( { color: 0x00ff00 } );
					 geometry.scale.set(0.5,0.5,0.5);
					 closebox = new Physijs.BoxMesh( geometry, material );

					 closebox.position.y = getY( worldHalfWidth, worldHalfDepth ) * 100 + 100;

					 //closebox.position.set(-40,20,-40);
					 closebox.castShadow = true;
					 scene.add( closebox  );
				 },
				 function(xhr){
					 console.log( (xhr.loaded / xhr.total * 100) + '% loaded' );},
				 function(err){console.log("error in loading: "+err);}
			 )
 }
*/
function initScene(){
  //scene = new THREE.Scene();
  var scene = new Physijs.Scene();
  scene.background = new THREE.Color( 0xbfd1e5 );
  return scene;
}

function randN(n){
	return Math.random()*n;
}

function addRain(){
  var numRain = 200;
     for (i=0;i<=numRain ; i++){
      var rain= createRain();
      rain.position.set(randN(10),getY( worldHalfWidth, worldHalfDepth ) * 100 + 2000,randN(20));
      scene.add(rain);
     }
 }

 function createRain(){
  var geometry = new THREE.SphereGeometry( 20, 16, 16 );
  //var texture = new THREE.TextureLoader().load( 'water.jpg' );
	//texture.wrapS = THREE.RepeatWrapping;
  //texture.wrapT = THREE.RepeatWrapping;
  //texture.repeat.set( 1, 1 );
  var material = new THREE.MeshLambertMaterial( {color:0x00008B} );
  var pmaterial = new Physijs.createMaterial(material,0.9,0.3);
  var mesh = new Physijs.SphereMesh( geometry, pmaterial,1000 );
  mesh.castShadow = true;
  return mesh;
 }


function createMainScene(){
  container = document.getElementById( 'container' );
  camera = new THREE.PerspectiveCamera( 60, window.innerWidth / window.innerHeight, 1, 20000 );
  camera.position.x = 1000;
	camera.position.y = getY( worldHalfWidth, worldHalfDepth ) * 100 + 100;
  camera.position.z = -1000;
	gameState.camera = camera;
/*
	controls = new THREE.FirstPersonControls( camera );
	controls.movementSpeed = 1000;
	controls.lookSpeed = 0.1;
	controls.lookVertical = true;
*/
	addRain();

  edgeCam = new THREE.PerspectiveCamera( 60, window.innerWidth / window.innerHeight, 1, 20000 );
  edgeCam.position.x=200;
  edgeCam.position.y=getY( worldHalfWidth, worldHalfDepth ) * 100;
  edgeCam.position.z = 200;

	mouse = new THREE.Vector2();

	avatarCam = new THREE.PerspectiveCamera( 60, window.innerWidth / window.innerHeight, 0.1, 1000 );


	avatar = createAvatar();
//	avatar.position.x = 2000;
	avatar.position.y = getY( worldHalfWidth, worldHalfDepth ) * 100+80;
	//avatar.position.z = 200;
	scene.add(avatar);





	//avatar = createAvatar();
	//avatar.position.y = getY( worldHalfWidth, worldHalfDepth ) * 100 + 100;
	//getY( worldHalfWidth, worldHalfDepth ) * 100 + 100;
	//avatarCam.translateY(-4);
	//avatarCam.translateZ(3);
	//scene.add(avatar);
	//gameState.camera = avatarCam;

	var light = new THREE.Color( 0xffffff );
	var shadow = new THREE.Color( 0x505050 );


	var matrix = new THREE.Matrix4();

	var geometry = new THREE.BoxGeometry( 20, 20, 20);
	var material = new THREE.MeshLambertMaterial( { color: 0x00aaaa} );
	var pmaterial = new Physijs.createMaterial(material,0.9,0.5);
	//var mesh = new THREE.Mesh( geometry, material );


	var pxGeometry = new THREE.PlaneGeometry( 100, 100 );
	var material2 = new THREE.MeshLambertMaterial( { map: texture, vertexColors: THREE.VertexColors } );
	var pmaterial2 = new Physijs.createMaterial(material2,0.9,0.5);
	pxGeometry.faces[ 0 ].vertexColors = [ light, shadow, light ];
	pxGeometry.faces[ 1 ].vertexColors = [ shadow, shadow, light ];
	pxGeometry.faceVertexUvs[ 0 ][ 0 ][ 0 ].y = 0.5;
	pxGeometry.faceVertexUvs[ 0 ][ 0 ][ 2 ].y = 0.5;
	pxGeometry.faceVertexUvs[ 0 ][ 1 ][ 2 ].y = 0.5;
	pxGeometry.rotateY( Math.PI / 2 );
	pxGeometry.translate( 50, 0, 0 );
	var mesh2 = new Physijs.ConvexMesh( pxGeometry, pmaterial2, 0 );
	scene.add( mesh2 );

	var nxGeometry = new THREE.PlaneGeometry( 100, 100 );
	var material3 = new THREE.MeshLambertMaterial( { map: texture, vertexColors: THREE.VertexColors } );
	var pmaterial3 = new Physijs.createMaterial(material3,0.9,0.5);
	nxGeometry.faces[ 0 ].vertexColors = [ light, shadow, light ];
	nxGeometry.faces[ 1 ].vertexColors = [ shadow, shadow, light ];
	nxGeometry.faceVertexUvs[ 0 ][ 0 ][ 0 ].y = 0.5;
	nxGeometry.faceVertexUvs[ 0 ][ 0 ][ 2 ].y = 0.5;
	nxGeometry.faceVertexUvs[ 0 ][ 1 ][ 2 ].y = 0.5;
	nxGeometry.rotateY( - Math.PI / 2 );
	nxGeometry.translate( - 50, 0, 0 );
	var mesh3 = new Physijs.ConvexMesh( nxGeometry, pmaterial3, 0 );
	scene.add( mesh3 );

	var pyGeometry = new THREE.PlaneGeometry( 100, 100 );
	var material4 = new THREE.MeshLambertMaterial( { map: texture, vertexColors: THREE.VertexColors } );
	var pmaterial4 = new Physijs.createMaterial(material4,0.9,0.5);
	pyGeometry.faces[ 0 ].vertexColors = [ light, light, light ];
	pyGeometry.faces[ 1 ].vertexColors = [ light, light, light ];
	pyGeometry.faceVertexUvs[ 0 ][ 0 ][ 1 ].y = 0.5;
	pyGeometry.faceVertexUvs[ 0 ][ 1 ][ 0 ].y = 0.5;
	pyGeometry.faceVertexUvs[ 0 ][ 1 ][ 1 ].y = 0.5;
	pyGeometry.rotateX( - Math.PI / 2 );
	pyGeometry.translate( 0, 50, 0 );
	var mesh4 = new Physijs.Mesh( pyGeometry, pmaterial4, 0 );
  scene.add( mesh4 );

	var py2Geometry = new THREE.PlaneGeometry( 100, 100 );
	var material5 = new THREE.MeshLambertMaterial( { map: texture, vertexColors: THREE.VertexColors } );
	var pmaterial5 = new Physijs.createMaterial(material5,0.9,0.5);
	py2Geometry.faces[ 0 ].vertexColors = [ light, light, light ];
	py2Geometry.faces[ 1 ].vertexColors = [ light, light, light ];
	py2Geometry.faceVertexUvs[ 0 ][ 0 ][ 1 ].y = 0.5;
	py2Geometry.faceVertexUvs[ 0 ][ 1 ][ 0 ].y = 0.5;
	py2Geometry.faceVertexUvs[ 0 ][ 1 ][ 1 ].y = 0.5;
	py2Geometry.rotateX( - Math.PI / 2 );
	py2Geometry.rotateY( Math.PI / 2 );
	py2Geometry.translate( 0, 50, 0 );
	var mesh5 = new Physijs.ConvexMesh( py2Geometry, pmaterial5, 0 );
	scene.add( mesh5 );

	var pzGeometry = new THREE.PlaneGeometry( 100, 100 );
	var material6 = new THREE.MeshLambertMaterial( { map: texture, vertexColors: THREE.VertexColors } );
	var pmaterial6 = new Physijs.createMaterial(material6,0.9,0.5);
	pzGeometry.faces[ 0 ].vertexColors = [ light, shadow, light ];
	pzGeometry.faces[ 1 ].vertexColors = [ shadow, shadow, light ];
	pzGeometry.faceVertexUvs[ 0 ][ 0 ][ 0 ].y = 0.5;
	pzGeometry.faceVertexUvs[ 0 ][ 0 ][ 2 ].y = 0.5;
	pzGeometry.faceVertexUvs[ 0 ][ 1 ][ 2 ].y = 0.5;
	pzGeometry.translate( 0, 0, 50 );
	var mesh6 = new Physijs.ConvexMesh( pzGeometry, pmaterial6, 0 );
	scene.add( mesh6 );

	var nzGeometry = new THREE.PlaneGeometry( 100, 100 );
	var material7 = new THREE.MeshLambertMaterial( { map: texture, vertexColors: THREE.VertexColors } );
	var pmaterial7 = new Physijs.createMaterial(material7,0.9,0.5);
	nzGeometry.faces[ 0 ].vertexColors = [ light, shadow, light ];
	nzGeometry.faces[ 1 ].vertexColors = [ shadow, shadow, light ];
	nzGeometry.faceVertexUvs[ 0 ][ 0 ][ 0 ].y = 0.5;
	nzGeometry.faceVertexUvs[ 0 ][ 0 ][ 2 ].y = 0.5;
	nzGeometry.faceVertexUvs[ 0 ][ 1 ][ 2 ].y = 0.5;
	nzGeometry.rotateY( Math.PI );
	nzGeometry.translate( 0, 0, - 50 );
	var mesh7 = new Physijs.ConvexMesh( nzGeometry, pmaterial7, 0 );
	scene.add( mesh7 );

	//
	var geometry = new THREE.PlaneGeometry( 100, 100 );
	var texture = new THREE.TextureLoader().load( '../textures/minecraft/atlas.png' );
	texture.magFilter = THREE.NearestFilter;
	texture.minFilter = THREE.LinearMipMapLinearFilter;
	var material1 = new THREE.MeshLambertMaterial( { map: texture, vertexColors: THREE.VertexColors } );
	var pmaterial1 = new Physijs.createMaterial(material1,0.9,0.5);
	var mesh1 = new Physijs.ConvexMesh( geometry, pmaterial1, 0 );
	scene.add( mesh1 );

	var group = new THREE.Object3D();
	//scene.add(group);

	var dummy = new THREE.Mesh();
	for ( var z = 0; z < worldDepth; z ++ ) {
		for ( var x = 0; x < worldWidth; x ++ ) {
			var h = getY( x, z );
			matrix.makeTranslation(
				x * 100 - worldHalfWidth * 100,
				h * 100,
				z * 100 - worldHalfDepth * 100
			);
			var px = getY( x + 1, z );
			var nx = getY( x - 1, z );
			var pz = getY( x, z + 1 );
			var nz = getY( x, z - 1 );
			var pxpz = getY( x + 1, z + 1 );
			var nxpz = getY( x - 1, z + 1 );
			var pxnz = getY( x + 1, z - 1 );
			var nxnz = getY( x - 1, z - 1 );
			var a = nx > h || nz > h || nxnz > h ? 0 : 1;
			var b = nx > h || pz > h || nxpz > h ? 0 : 1;
			var c = px > h || pz > h || pxpz > h ? 0 : 1;
			var d = px > h || nz > h || pxnz > h ? 0 : 1;
			if ( a + c > b + d ) {
				var colors = py2Geometry.faces[ 0 ].vertexColors;
				colors[ 0 ] = b === 0 ? shadow : light;
				colors[ 1 ] = c === 0 ? shadow : light;
				colors[ 2 ] = a === 0 ? shadow : light;
				var colors = py2Geometry.faces[ 1 ].vertexColors;
				colors[ 0 ] = c === 0 ? shadow : light;
				colors[ 1 ] = d === 0 ? shadow : light;
				colors[ 2 ] = a === 0 ? shadow : light;
				//group.add(mesh5);
				geometry.merge( py2Geometry, matrix );
			} else {
				var colors = pyGeometry.faces[ 0 ].vertexColors;
				colors[ 0 ] = a === 0 ? shadow : light;
				colors[ 1 ] = b === 0 ? shadow : light;
				colors[ 2 ] = d === 0 ? shadow : light;
				var colors = pyGeometry.faces[ 1 ].vertexColors;
				colors[ 0 ] = b === 0 ? shadow : light;
				colors[ 1 ] = c === 0 ? shadow : light;
				colors[ 2 ] = d === 0 ? shadow : light;
				geometry.merge( pyGeometry, matrix );
			}
			if ( ( px != h && px != h + 1 ) || x == 0 ) {
				var colors = pxGeometry.faces[ 0 ].vertexColors;
				colors[ 0 ] = pxpz > px && x > 0 ? shadow : light;
				colors[ 2 ] = pxnz > px && x > 0 ? shadow : light;
				var colors = pxGeometry.faces[ 1 ].vertexColors;
				colors[ 2 ] = pxnz > px && x > 0 ? shadow : light;
				geometry.merge( pxGeometry, matrix );
			}
			if ( ( nx != h && nx != h + 1 ) || x == worldWidth - 1 ) {
				var colors = nxGeometry.faces[ 0 ].vertexColors;
				colors[ 0 ] = nxnz > nx && x < worldWidth - 1 ? shadow : light;
				colors[ 2 ] = nxpz > nx && x < worldWidth - 1 ? shadow : light;
				var colors = nxGeometry.faces[ 1 ].vertexColors;
				colors[ 2 ] = nxpz > nx && x < worldWidth - 1 ? shadow : light;
				geometry.merge( nxGeometry, matrix );
			}
			if ( ( pz != h && pz != h + 1 ) || z == worldDepth - 1 ) {
				var colors = pzGeometry.faces[ 0 ].vertexColors;
				colors[ 0 ] = nxpz > pz && z < worldDepth - 1 ? shadow : light;
				colors[ 2 ] = pxpz > pz && z < worldDepth - 1 ? shadow : light;
				var colors = pzGeometry.faces[ 1 ].vertexColors;
				colors[ 2 ] = pxpz > pz && z < worldDepth - 1 ? shadow : light;
				geometry.merge( pzGeometry, matrix );
			}
			if ( ( nz != h && nz != h + 1 ) || z == 0 ) {
				var colors = nzGeometry.faces[ 0 ].vertexColors;
				colors[ 0 ] = pxnz > nz && z > 0 ? shadow : light;
				colors[ 2 ] = nxnz > nz && z > 0 ? shadow : light;
				var colors = nzGeometry.faces[ 1 ].vertexColors;
				colors[ 2 ] = nxnz > nz && z > 0 ? shadow : light;
				geometry.merge( nzGeometry, matrix );
			}
		}
	}

	var texture = new THREE.TextureLoader().load( '../textures/minecraft/atlas.png' );
	texture.magFilter = THREE.NearestFilter;
	texture.minFilter = THREE.LinearMipMapLinearFilter;
	var material1 = new THREE.MeshLambertMaterial( { map: texture, vertexColors: THREE.VertexColors } );
	var pmaterial1 = new Physijs.createMaterial(material1,0.9,0.5);
	var mesh1 = new Physijs.Mesh( geometry, pmaterial1, 0 );
	scene.add( mesh1 );

	var ambientLight = new THREE.AmbientLight( 0xcccccc );
	scene.add( ambientLight );

	var directionalLight = new THREE.DirectionalLight( 0xffffff, 2 );
	directionalLight.position.set( 1, 1, 0.5 ).normalize();
	scene.add( directionalLight );

	objects.push(avatar);

	container.innerHTML = "";
	container.appendChild( renderer.domElement );
	stats = new Stats();
	//container.appendChild( stats.dom );
	//
	window.addEventListener( 'resize', onWindowResize, false );
  window.addEventListener( 'keydown', keydown, false);
	window.addEventListener( 'mouseMove', onDocumentMouseMove, false);
	window.addEventListener( 'mousedown', onDocumentMouseDown, false)
}

function onWindowResize() {
	camera.aspect = window.innerWidth / window.innerHeight;
	camera.updateProjectionMatrix();
	renderer.setSize( window.innerWidth, window.innerHeight );
	controls.handleResize();
}

function createAvatar(){
	//var geometry = new THREE.SphereGeometry( 4, 20, 20);
	var geometry = new THREE.BoxGeometry( 50, 50, 50);
	var material = new THREE.MeshLambertMaterial( { color: 0x0000ff} );
	var pmaterial = new Physijs.createMaterial(material,0.9,0.5);
	//var mesh = new THREE.Mesh( geometry, material );
	var mesh = new Physijs.BoxMesh( geometry, pmaterial, 0 );
	mesh.setDamping(0.1,0.1);
	mesh.castShadow = true;
	avatarCam.position.set(0,4,0);
	avatarCam.lookAt(0,4,10);
	mesh.add(avatarCam);
	mesh.position.set(0,0,0)
	return mesh;
}

function createBall(){
	//var geometry = new THREE.SphereGeometry( 4, 20, 20);
	var geometry = new THREE.SphereGeometry( 20, 20, 20);
	var material = new THREE.MeshLambertMaterial( { color: 0xffff00} );
	var pmaterial = new Physijs.createMaterial(material,0.9,0.95);
	var mesh = new Physijs.BoxMesh( geometry, pmaterial, 1 );
	mesh.setDamping(0.1,0.1);
	mesh.castShadow = true;
	console.log("Success!");
	return mesh;

	ball.addEventListener( 'collision',
		function( other_object, relative_velocity, relative_rotation, contact_normal ) {
			if (other_object==avatar){
				console.log("ball "+i+" hit the cone");
				soundEffect('good.wav');
				gameState.score += 1;  // add one to the score
				if (gameState.score==2) {
					gameState.scene='youwon';
				}
			}
		}
	)
}
/*
function addBall(){
	ball = createBall();
	var position = camera.position;
	ball.position.set(position);
	ball.setLinearVelocity(new THREE.Vector3(20,0,0));
	scene.add(ball);
	console.log("Incoming!");

	ball.addEventListener( 'collision',
		function( other_object, relative_velocity, relative_rotation, contact_normal ) {
			if (other_object==avatar){
				console.log("ball "+i+" hit the cone");
				soundEffect('good.wav');
				gameState.score += 1;  // add one to the score
				//gameState.health += 1;
				/*
				if (gameState.score==10) {
					gameState.scene='youwon';
				}*/
				//scene.remove(ball);  // this isn't working ...
				// make the ball drop below the scene ..
				// threejs doesn't let us remove it from the schene...
				//this.position.y = this.position.y - 100;
				//this.__dirtyPosition = true;
		//	}
		/*
			else if (other_object == cone){
				gameState.health +=1;
			}else if(other_object == avatar){
				gameState.health += 1;
			}
		}
	)
}
*/

function generateHeight( width, height ) {
	var data = [], perlin = new ImprovedNoise(),
	size = width * height, quality = 2, z = Math.random() * 100;
	for ( var j = 0; j < 4; j ++ ) {
		if ( j === 0 ) for ( var i = 0; i < size; i ++ ) data[ i ] = 0;
		for ( var i = 0; i < size; i ++ ) {
			var x = i % width, y = ( i / width ) | 0;
			data[ i ] += perlin.noise( x / quality, y / quality, z ) * quality;
		}
		quality *= 4;
	}
	return data;
}

function getY( x, z ) {
	return ( data[ x + z * worldWidth ] * 0.2 ) | 0;
}

function initControls(){

	// here is where we create the eventListeners to respond to operations

		//create a clock for the time-based animation ...
		clock = new THREE.Clock();
		clock.start();

		window.addEventListener( 'keydown', keydown);
		window.addEventListener( 'keyup',   keyup );
}
/*
function createB(){
	var geometry = new THREE.SphereGeometry(10,10,10);
	var material = new THREE.MeshLambertMaterial({color:0xff00ff});
	var pmaterial = new Physijs.createMaterial(material,0.95,0.5);
	var mesh = new Physijs.BoxMesh(geometry,pmaterial);
	mesh.setDamping(0.1,0.1);
	mesh.castShadow = true;
	return mesh
}
*/
function throwBall(){
	var ball = new Physijs.SphereMesh(
		new THREE.SphereGeometry(10,10,10),
		new THREE.MeshLambertMaterial({color:0xff00ff})
	)
	//getY( worldHalfWidth, worldHalfDepth ) * 100 + 100
	ball.position.set(camera.position.x, camera.position.y, camera.position.z);
	//ball.setLinearVelocity(new THREE.Vector3(0,0,-1000))
	scene.add(ball)
	//ball.position.x+=100;
	ball.setLinearVelocity(new THREE.Vector3(0,0,-500))
	console.dir(ball)

	ball.addEventListener( 'collision',
		function( other_object, relative_velocity, relative_rotation, contact_normal ) {
			if (other_object==avatar){
				//console.log("ball "+i+" hit the cone");
				//soundEffect('good.wav');
				gameState.score += 50;  // add one to the score
				avatar.position.x += 100;
				console.log("score: "+gameState.score);
				if (gameState.score==500) {
					gameState.scene='youwon';
				}
			}
		}
	)

}

function onDocumentMouseMove( event ) {
				event.preventDefault();
				mouse.set( ( event.clientX / window.innerWidth ) * 2 - 1, - ( event.clientY / window.innerHeight ) * 2 + 1 );
				raycaster.setFromCamera( mouse, camera );
				var intersects = raycaster.intersectObjects( objects );
				if ( intersects.length > 0 ) {
					var intersect = intersects[ 0 ];
					avatar.rotateX(1);
				}
				render();
			}

function onDocumentMouseDown( event ) {
	event.preventDefault();
	mouse.set( ( event.clientX / window.innerWidth ) * 2 - 1, - ( event.clientY / window.innerHeight ) * 2 + 1 );
	raycaster.setFromCamera( mouse, camera );
	var intersects = raycaster.intersectObjects( objects );
	if ( intersects.length > 0 ) {
		var intersect = intersects[ 0 ];
		// delete cube
		if ( isShiftDown ) {
			if ( intersect.object != plane ) {
				scene.remove( intersect.object );
				objects.splice( objects.indexOf( intersect.object ), 1 );
			}
		// create cube
		} else {
			avatar.position.set(0,-1000,0);
		}
		render();
	}
}


function keydown(event){
	console.log("Keydown: '"+event.key+"'");
	//console.dir(event);
	// first we handle the "play again" key in the "youwon" scene
	// this is the regular scene
	switch (event.key){
		// change the way the avatar is moving
		case "w": controls.fwd = true;  break;
		case "s": controls.bwd = true; break;
		case "a": controls.left = true; break;
		case "d": controls.right = true; break;
		case "r": controls.up = true; break;
		case "f": controls.down = true; break;
		case "m": controls.speed = 30; break;
		case " ": controls.fly = true;
				console.log("space!!");
				break;
		case "h": controls.reset = true; break;
		case "q": controls.rotateToLeft = true; break;
		case "e": controls.rotateToRight = true; break;
		case "j": controls.launch = true; break;
		case "k": throwBall(); break;


		// switch cameras
		case "1": gameState.camera = camera; break;
		case "2": gameState.camera = avatarCam; break;
		case "3": gameState.camera = edgeCam; break;

		// move the camera around, relative to the avatar
		case "ArrowLeft": avatarCam.translateY(1);break;
		case "ArrowRight": avatarCam.translateY(-1);break;
		case "ArrowUp": avatarCam.translateZ(-1);break;
		case "ArrowDown": avatarCam.translateZ(1);break;

	}

}


function keyup(event){
	//console.log("Keydown:"+event.key);
	//console.dir(event);
	switch (event.key){
		case "w": controls.fwd   = false;  break;
		case "s": controls.bwd   = false; break;
		case "a": controls.left  = false; break;
		case "d": controls.right = false; break;
		case "r": controls.up    = false; break;
		case "f": controls.down  = false; break;
		case "m": controls.speed = 10; break;
		case " ": controls.fly = false; break;
		case "h": controls.reset = false; break;
		case "q": controls.rotateToLeft = false; break;
		case "e": controls.rotateToRight = false; break;
		case "j": controls.launch = false; break;
	}
}
/*
function launchBalls(){
	if(controls.launch){
		//scene.add()
		var ballball = addBall();
	}
}
*/

function updateAvatar(){
	"change the avatar's linear or angular velocity based on controls state (set by WSAD key presses)"

	var forward = camera.getWorldDirection();
	var goLeft = camera.getWorldDirection();

	//var axes = new THREE.AxisHelper(10);

	//var temp = new THREE.Object3D();
	//temp.add(camera);

	if (controls.fwd){
		//avatar.setLinearVelocity(forward.multiplyScalar(controls.speed));
		camera.position.z -= 5;
	} else if (controls.bwd){
		//avatar.setLinearVelocity(forward.multiplyScalar(-controls.speed));
		camera.position.z += 5;
	}

	if (controls.fly){
		//avatar.setLinearVelocity(new THREE.Vector3(0,controls.speed,0));
		camera.position.y +=5;
	}else if(controls.down){
		camera.position.y -=5;
	}

	if (controls.left){
		//avatar.setAngularVelocity(new THREE.Vector3(0,controls.speed*0.1,0));
		camera.position.x -= 5;
	} else if (controls.right){
		camera.position.x += 5;
	}
/**
	if(controls.launch){
		//scene.add()
		ball = createBall();
		var position = camera.position;
		ball.position.set(position);
		ball.setLinearVelocity(new THREE.Vector3(20,0,0));
		scene.add(ball);
		console.log("Incoming!");
	}
	*/


	if(controls.rotateToLeft){
		camera.rotateY(Math.PI*0.01);
	}else if(controls.rotateToRight){
		camera.rotateY(-Math.PI*0.01);
	}


	if (controls.reset){
		avatar.__dirtyPosition = true;
		avatar.position.set(40,10,40);
	}

}

function onMouseDown(event){
      event.preventDefault();
      mouseDown = true;
      mouseX = event.clientX;//出发事件时的鼠标指针的水平坐标

      rotateStart.set( event.clientX, event.clientY );
      document.addEventListener( 'mousemove', onMouseMove2, false );
  }

function onMouseup(event){
	    mouseDown = false;

	    document.removeEventListener("mousemove", onMouseMove2);
	}

	function onMouseMove2(event){
	        if(!mouseDown){
	            return;
	        }
	        var deltaX = event.clientX - mouseX;
	        mouseX = event.clientX;
	        rotateScene(deltaX);
	    }






function animate() {
	//requestAnimationFrame( animate );
	//render();
	stats.update();
	updateAvatar();

	requestAnimationFrame( animate );

	switch(gameState.scene) {

		case "youwon":
			//endText.rotateY(0.005);
			renderer.render(endScene, endCamera);
			break;

		case "main":
			edgeCam.lookAt(avatar.position);
			scene.simulate();
			if (gameState.camera!= 'none'){
				renderer.render( scene, gameState.camera );
			}
			break;

		default:
			console.log("don't know the scene "+gameState.scene);

	//draw heads up display ..
  var info = document.getElementById("info");
	//var info1 = document.getElementById("info1");
	info.innerHTML='<div style="font-size:24pt">Score: ' + gameState.score + ';  Health: ' + gameState.health +'</div>';
	//info1.innerHTML='<div style="font-size:24pt">Health: ' + gameState.health + '</div>';
}

	function render() {
		//controls.update( clock.getDelta() );
		renderer.render( scene, camera );
	}
}
/*
function animate() {
				requestAnimationFrame( animate );
				render();
				stats.update();
			}
function render() {
	controls.update( clock.getDelta() );
	renderer.render( scene, camera );
}
*/
