
/*
* Introduction:
* This is a marble game. At the beginning, the user need to press the space bar
* to launch a small ball into the game. Then the user need to use ArrowLeft and
* ArrowRight to control the springboard to bounce back the balls. There are many
* other objects in this game, when the ball hits an object, the player will get
* a specific scores. Hitting different objects will get different scores.
*/

//Let's begin
//First, we need to declare some variables
// in the animation code
var scene, renderer;  // all threejs programs need these
var camera, avatarCam, edgeCam;  // we have two cameras in the main scene
var ball; //This is the ball that player need to launch and bounce back

var leftBouncePlate, rightBouncePlate;

var controls =
     {leftUP:false, rightUP:false, bothUP:false, camera:camera}

var gameState =
     {score:0, health:3, scene:'main', camera:'none' }


// Here is the main game control
init(); //
initControls();
animate();  // start the animation loop!

/**
  To initialize the scene, we initialize each of its components
*/
function init(){
    initPhysijs();
    scene = initScene();
    initRenderer();
    createMainScene();
}

//------------------------------------------------------------------------------

// This part creats some very basic elements of the game
// When you add something in this program, remeber to add it in this main method

function createMainScene(){
  // setup lighting
  var light1 = createPointLight();
  light1.position.set(10,200,20);
  scene.add(light1);
  var light2 = createPointLight();
  light2.position.set(100,40,0);
  scene.add(light2);
  var light3 = createPointLight();
  light3.position.set(0,90,-210);
  scene.add(light3);
  var light0 = new THREE.AmbientLight( 0xffffff,0.25);
  scene.add(light0);


  // create main camera
  camera = new THREE.PerspectiveCamera( 90, window.innerWidth / window.innerHeight, 0.1, 1000 );
  camera.position.set(100,90,0);
  camera.lookAt(0,90,0);
  gameState.camera = camera;

  // create the ground and the skybox
  var ground = createGround('land.png');
  scene.add(ground);
  //var skybox = createSkyBox('sky.jpg',1);
  //scene.add(skybox);

  edgeCam = new THREE.PerspectiveCamera( 60, window.innerWidth / window.innerHeight, 0.1, 1000 );
  edgeCam.position.set(0,90,-200);
  edgeCam.lookAt(0,90,0);

  bottomCam = new THREE.PerspectiveCamera( 60, window.innerWidth / window.innerHeight, 0.1, 1000 );
  bottomCam.position.set(0,90,200);
  bottomCam.lookAt(0,90,0);

  ball = new createBall();
  ball.position.set(0,10,-75);
  ball.receiveShadow = false;
  scene.add(ball);

  var backPlate = new createOB(0xffffff);
  backPlate.scale.set(120,150,0.5);
  backPlate.position.set(-9,100,0);
  backPlate.receiveShadow = false;
  backPlate.rotateY(Math.PI/2);
  scene.add(backPlate);

  var leftPlate = new createPlate(0x00ff00);
  leftPlate.scale.set(15,150,5);
  leftPlate.position.set(0,100,60);
  leftPlate.receiveShadow = false;
  leftPlate.rotateY(Math.PI);
  scene.add(leftPlate);

  var rightPlate = new createPlate(0x00ff00);
  rightPlate.scale.set(15,130,5);
  rightPlate.position.x=0;
  rightPlate.position.y=75;
  rightPlate.position.z=-60;
  rightPlate.receiveShadow = false;
  rightPlate.rotateY(Math.PI);
  scene.add(rightPlate);

  var topPlate = new createPlate(0x0000ff);
  topPlate.scale.set(15,125,5);
  topPlate.position.set(0,175,0);
  topPlate.receiveShadow = false;
  topPlate.rotateX(Math.PI/2);
  scene.add(topPlate);

  var bottomPlate1 = new createPlate(0x0000ff);
  bottomPlate1.scale.set(15,24,5);
  bottomPlate1.position.set(0,24,51);
  bottomPlate1.receiveShadow = false;
  bottomPlate1.rotateX(Math.PI/2);
  scene.add(bottomPlate1);

  var bottomPlate2 = new createPlate(0x0000ff);
  bottomPlate2.scale.set(15,24,5);
  bottomPlate2.position.set(0,24,-51);
  bottomPlate2.receiveShadow = false;
  bottomPlate2.rotateX(Math.PI/2);
  scene.add(bottomPlate2);

  var frontPlate = new createTransparentPlate(0xffffff);
  frontPlate.scale.set(120,150,0.5);
  frontPlate.position.set(10,100,0);
  frontPlate.receiveShadow = false;
  frontPlate.rotateY(Math.PI/2);
  scene.add(frontPlate);

  leftBouncePlate = new createBP(0x00ff00);
  leftBouncePlate.scale.set(20,5,50);
  leftBouncePlate.position.set(1.5,22,30);
  leftBouncePlate.receiveShadow = false;
  leftBouncePlate.rotateX(2*Math.PI/3);
  scene.add(leftBouncePlate);

  rightBouncePlate = new createBP(0x00ff00);
  rightBouncePlate.scale.set(20,5,50);
  rightBouncePlate.position.set(1.5,22,-30);
  rightBouncePlate.receiveShadow = false;
  rightBouncePlate.rotateX(-2*Math.PI/3);
  scene.add(rightBouncePlate);
/*
  var tube = new createTube(0xff0000,20,8,30,100,2.5);
  //tube.scale.set(10,2,30,100,3);
  tube.position.set(0,142,-55);
  tube.receiveShadow = false;
  tube.rotateY(Math.PI/2);
  tube.rotateZ(-Math.PI/15);
  scene.add(tube);
  */
/*
  var outBack = new createPlate(0xff00ff);
  outBack.scale.set(15,180,1);
  outBack.position.set(-8,100,-80);
  outBack.receiveShadow = false;
  outBack.rotateY(Math.PI/2);
  scene.add(outBack);

  var outRight = new createPlate(0xffffff);
  outRight.scale.set(15,180,1);
  outRight.position.set(-1,100,-87);
  outRight.receiveShadow = false;
  outRight.rotateY(Math.PI);
  scene.add(outRight);

  var outFront = new createPlate(0x00ffff);
  outFront.scale.set(15,180,1);
  outFront.position.set(7,100,-75);
  outFront.receiveShadow = false;
  outFront.rotateY(Math.PI/2);
  scene.add(outFront);

  var outBottom = new createPlate(0xffff00);
  outBottom.scale.set(15,15,1);
  outBottom.position.set(3,13,-75);
  outBottom.receiveShadow = false;
  outBottom.rotateX(Math.PI/2);
  scene.add(outBottom);
*/
/*
  var launchTube = new createTube(0xff00ff,9,9,160);
  launchTube.position.set(0,80,-75);
  launchTube.receiveShadow = false;
  scene.add(launchTube);

  var tube = new createCurveTube(0xff0000,20,8,30,100,2.5);
  //tube.scale.set(10,2,30,100,3);
  tube.position.set(2,142,-55);
  tube.receiveShadow = false;
  tube.rotateY(Math.PI/2);
  tube.rotateZ(-Math.PI/15);
  scene.add(tube);
*/
/*
  var launchBoard = new createPlate(0xff00ff);
  launchBoard.scale.set(20,5,50);
  launchBoard.position.set(2,160,-76);
  launchBoard.receiveShadow = false;
  launchBoard.rotateX(2*Math.PI/3);
  scene.add(launchBoard);
*/
  addLaunchCloseBoard();


  var launchPlate = new createBoxMesh(0x0000ff);
  launchPlate.scale.set(13,13,13);
  launchPlate.position.set(0,6.5,-75);
  launchPlate.receiveShadow = false;
  scene.add(launchPlate);

  var insidePlate1 = new createBouncePlate(0x0000ff,10,10,10,100);
  insidePlate1.scale.set(1,2,1);
  insidePlate1.position.set(-2,80,25);
  insidePlate1.receiveShadow = false;
  insidePlate1.rotateZ(Math.PI/2);
  scene.add(insidePlate1);


  var insidePlate2 = new createBouncePlate(0x0000ff,10,10,10,100);
  insidePlate2.scale.set(1,2,1);
  insidePlate2.position.set(-2,80,-30);
  insidePlate2.receiveShadow = false;
  insidePlate2.rotateZ(Math.PI/2);
  scene.add(insidePlate2);


  var insideBoard = new createInsideBoard(0x00ff00);
  insideBoard.scale.set(20,5,50);
  insideBoard.position.set(-2,100,0);
  insideBoard.receiveShadow = false;
  insideBoard.rotateX(-2*Math.PI/1);
  scene.add(insideBoard);


}

//------------------------------------------------------------------------------
//This part is about the function we build the traces and elements


function addLaunchCloseBoard(){

  var launchBoard = new createPlate(0xff00ff);
  launchBoard.scale.set(20,5,50);
  launchBoard.position.set(2,160,-76);
  launchBoard.receiveShadow = false;
  launchBoard.rotateX(2*Math.PI/3);
  scene.add(launchBoard);

  var launchCloseBoard = new createPlate(0xff00ff);
  launchCloseBoard.scale.set(20,5,50);
  launchCloseBoard.position.set(0,200,-60);
  launchCloseBoard.receiveShadow = false;
  launchCloseBoard.rotateX(Math.PI/2);
  scene.add(launchCloseBoard);

  ball.addEventListener('collision',
    function(other_object, relative_velocity, relative_rotation, contact_normal){
      if(other_object == launchBoard){
        console.log("ball hit the plate");
        launchBoard.rotateX(1);
      }
      this.__dirtyPosition = true;
    }
  );
/**
  ball.addEventListener('collision',
    function(other_object, relative_velocity, relative_rotation, contact_normal){
      if(other_object == ball){
        console.log("ball hit the plate");
        launchBoard.rotateX(-1);
      }
      this.__dirtyPosition = true;
    }
  )
  */
}

function createPlate(color,w,h,d){
  var geometry = new THREE.BoxGeometry( w, h, d);
  var material = new THREE.MeshLambertMaterial( { color: color, transparent:true, opacity:0.1} );
  mesh = new Physijs.BoxMesh( geometry, material, 0);
  //mesh = new Physijs.BoxMesh( geometry, material,0 );
  mesh.castShadow = true;
  return mesh;
}

function createBP(color,w,h,d){
  var geometry = new THREE.BoxGeometry( w, h, d);
  var material = new THREE.MeshLambertMaterial( { color: color,transparent:true, opacity:1} );
  var pmaterial = new Physijs.createMaterial(material,0.9,2.5);
  mesh = new Physijs.BoxMesh( geometry, pmaterial, 0 );
  //mesh = new Physijs.BoxMesh( geometry, material,0 );
  mesh.castShadow = true;
  return mesh;
}

function createTransparentPlate(color,w,h,d){
  var geometry = new THREE.BoxGeometry( w, h, d);
  var material = new THREE.MeshLambertMaterial( { color: color, transparent:true, opacity:0.1} );
  mesh = new Physijs.BoxMesh( geometry, material, 0 );
  //mesh = new Physijs.BoxMesh( geometry, material,0 );
  mesh.castShadow = true;
  return mesh;
}

function createBouncePlate(color,w,h,d,f){
  var geometry = new THREE.CylinderBufferGeometry(w,h,d,f);
  var material = new THREE.MeshBasicMaterial( { color: color} );
  var pmaterial = new Physijs.createMaterial(material,0.9,20);
  mesh = new Physijs.BoxMesh( geometry, pmaterial, 0 );
  mesh.setDamping(0.1,0.1);
  //mesh = new Physijs.BoxMesh( geometry, material,0 );
  mesh.castShadow = true;
  return mesh;
}

function createBall(){
  //var geometry = new THREE.SphereGeometry( 4, 20, 20);
  var geometry = new THREE.SphereGeometry( 5, 15, 15);
  var texture = new THREE.TextureLoader().load( '../images/golf.jpg' );
  var material = new THREE.MeshStandardMaterial( { color: 0xffffff, map: texture} );
  var pmaterial = new Physijs.createMaterial(material,0.9,0.98);
  var mesh = new Physijs.BoxMesh( geometry, pmaterial, 0.01);
  //mesh.setDamping(0.1,0.1);
  mesh.castShadow = true;
  return mesh;
}

function createTube(color,w,h,d,r){
  var geometry = new THREE.CylinderBufferGeometry( w, h, d, r );
  var material = new THREE.MeshBasicMaterial( {color: color, transparent:true, opacity:0.1} );
  var cylinder = new THREE.Mesh( geometry, material );
  return cylinder;
}

function createCurveTube(color,w,h,d,r,a){
  var geometry = new THREE.TorusBufferGeometry(w,h,d,r,a);
  var material = new THREE.MeshBasicMaterial({color:color,transparent:true, opacity:0.1});
  var pmaterial = new Physijs.createMaterial(material,0,0);
  mesh = new Physijs.BoxMesh( geometry, pmaterial, 0 );
  return mesh;
}

function createBoxMesh(color){
  var geometry = new THREE.BoxGeometry( 1, 1, 1);
  var material = new THREE.MeshLambertMaterial( { color: color} );
  mesh = new Physijs.BoxMesh( geometry, material, 0.1);
  //mesh = new Physijs.BoxMesh( geometry, material,0 );
  mesh.castShadow = true;
  return mesh;
}

function createOB(color,w,h,d){
  var geometry = new THREE.BoxGeometry( w, h, d);
  var texture = new THREE.TextureLoader().load( '../images/star.jpg' );
  var material = new THREE.MeshLambertMaterial( { color: color, map: texture, transparent:true, opacity:0.3} );
  mesh = new Physijs.BoxMesh( geometry, material, 0);
  //mesh = new Physijs.BoxMesh( geometry, material,0 );
  mesh.castShadow = true;
  return mesh;
}

function createInsideBoard(color,w,h,d){
  var geometry = new THREE.BoxGeometry( w, h, d);
  var material = new THREE.MeshLambertMaterial( { color: color,transparent:true, opacity:0.7} );
  var pmaterial = new Physijs.createMaterial(material,0.95,5);
  mesh = new Physijs.BoxMesh( geometry, pmaterial, 0 );
  //mesh = new Physijs.BoxMesh( geometry, material,0 );
  mesh.castShadow = true;
  return mesh;
}

function createInsideCube(color,w,h,d){
  var geometry = new THREE.BoxGeometry( w,h,d);
  var material = new THREE.MeshLambertMaterial( { color: color,transparent:true, opacity:0.7} );
  var pmaterial = new Physijs.createMaterial(material,0.95,5);
  mesh = new Physijs.BoxMesh( geometry, pmaterial, 0 );
  //mesh = new Physijs.BoxMesh( geometry, material,0 );
  mesh.castShadow = true;
  return mesh;
}

//------------------------------------------------------------------------------
// This part is the default part. All the codes need this part

// DO NOT CHANGE ANYTHING IN THIS PART!!!!

/* We don't do much here, but we could do more!
*/
function initScene(){
  //scene = new THREE.Scene();
  var scene = new Physijs.Scene();
  return scene;
}
// initialize the physijs
function initPhysijs(){
  Physijs.scripts.worker = '/js/physijs_worker.js';
  Physijs.scripts.ammo = '/js/ammo.js';
}
/*
  The renderer needs a size and the actual canvas we draw on
  needs to be added to the body of the webpage. We also specify
  that the renderer will be computing soft shadows
*/
function initRenderer(){
  renderer = new THREE.WebGLRenderer();
  renderer.setSize( window.innerWidth, window.innerHeight-50 );
  document.body.appendChild( renderer.domElement );
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
}

function createPointLight(){
  var light;
  light = new THREE.PointLight( 0xffffff);
  light.castShadow = true;
  //Set up shadow properties for the light
  light.shadow.mapSize.width = 2048;  // default
  light.shadow.mapSize.height = 2048; // default
  light.shadow.camera.near = 0.5;       // default
  light.shadow.camera.far = 500      // default
  return light;
}

function createGround(image){
  // creating a textured plane which receives shadows
  var geometry = new THREE.PlaneGeometry( 250, 250, 250 );
  var texture = new THREE.TextureLoader().load( '../images/'+image );
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set( 15, 15 );
  var material = new THREE.MeshLambertMaterial( { color: 0xffffff,  map: texture ,side:THREE.DoubleSide} );
  var pmaterial = new Physijs.createMaterial(material,0.9,0.05);
  //var mesh = new THREE.Mesh( geometry, material );
  var mesh = new Physijs.BoxMesh( geometry, pmaterial, 0 );
  mesh.receiveShadow = true;
  mesh.rotateX(Math.PI/2);
  return mesh
  // we need to rotate the mesh 90 degrees to make it horizontal not vertical
}

function createSkyBox(image,k){
  // creating a textured plane which receives shadows
  var geometry = new THREE.SphereGeometry( 500, 500, 500 );
  var texture = new THREE.TextureLoader().load( '../images/'+image );
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  texture.repeat.set( k, k );
  var material = new THREE.MeshLambertMaterial( { color: 0xffffff,  map: texture ,side:THREE.DoubleSide} );
  //var pmaterial = new Physijs.createMaterial(material,0.9,0.5);
  //var mesh = new THREE.Mesh( geometry, material );
  var mesh = new THREE.Mesh( geometry, material, 0 );
  mesh.receiveShadow = false;
  return mesh
  // we need to rotate the mesh 90 degrees to make it horizontal not vertical
}

//------------------------------------------------------------------------------
// This part add the initControls

//------------------------------------------------------------------------------
// This part allows the user to control the race car via keyboard

var clock;
function initControls(){
  // here is where we create the eventListeners to respond to operations
    //create a clock for the time-based animation ...
    clock = new THREE.Clock();
    clock.start();

    window.addEventListener( 'keydown', keydown);
    window.addEventListener( 'keyup',   keyup );
}

function keydown(event){
  console.log("Keydown: '"+event.key+"'");
  //console.dir(event);
  // first we handle the "play again" key in the "youwon" scene
  if (gameState.scene == 'youwon' && event.key=='r') {
    gameState.scene = 'main';
    gameState.score = 0;
    //addBalls();
    return;
  }

  if(gameState.scene == 'initialPicture' && event.key=='p'){
    gameState.scene = 'main';
    gameState.score = 0;
    return;
  }

  if(gameState.scene=='youlose'&&event.key=='r'){
    gameState.scene = 'main';
    gameState.score = 0;
    return;
  }

  // this is the regular scene
  switch (event.key){
    // change the way the avatar is moving
    case "f": controls.leftUP = true; break;
    case "j": controls.rightUP = true; break;
    case "1": gameState.camera = camera; break;
    case "2": gameState.camera = bottomCam; break;
    case "3": gameState.camera = edgeCam; break;
  }
}

function keyup(event){
  //console.log("Keydown:"+event.key);
  //console.dir(event);
  switch (event.key){
    case "f": controls.leftUP = false; break;
    case "j": controls.rightUP = false; break;
  }
}

function updateAvatar(){
  "change the avatar's linear or angular velocity based on controls state (set by WSAD key presses)"

  if(controls.leftUP){
    leftBouncePlate.rotateX(1);
  }else if(controls.rightUP){
    rightBouncePlate.rotateX(-1);
  }

}


//------------------------------------------------------------------------------

function animate() {
  var counter = 0;
  requestAnimationFrame( animate );


  switch(gameState.scene) {
/*
    case "youwon":
      endText.rotateY(0.005);
      renderer.render( endScene, endCamera );
      break;
*/
    case "main":
      updateAvatar();
      scene.simulate();
      if (gameState.camera!= 'none'){
        renderer.render( scene, gameState.camera );
      }
      break;

    default:
      console.log("don't know the scene "+gameState.scene);
  }
  //draw heads up display ..
  var info = document.getElementById("info");
  info.innerHTML='<div style="font-size:24pt">Score: ' + gameState.score + '</div>';
}
