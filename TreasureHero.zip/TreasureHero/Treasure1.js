if ( ! Detector.webgl ) {
				Detector.addGetWebGLMessage();
				document.getElementById( 'container' ).innerHTML = "";
			}

var container, stats;
var camera, controls, scene, renderer,edgeCam;
var mesh;
var worldWidth = 128, worldDepth = 128, worldHalfWidth = worldWidth / 2, worldHalfDepth = worldDepth / 2, data = generateHeight( worldWidth, worldDepth );
var clock = new THREE.Clock();

var controls =
		 {fwd:false, bwd:false, left:false, right:false,
			speed:10, fly:false, reset:false, rotateToLeft:false, rotateToRight:false,
			avatarCamAngle:Math.PI};
var gameState =
     {score:0, health:3, scene:'main', camera:'none' };


init();
initControls();
animate();

function init(){
  initPhysijs();
  initRenderer();
  scene = initScene();
  createMainScene();
}

function initPhysijs(){
  Physijs.scripts.worker = '/js/physijs_worker.js';
  Physijs.scripts.ammo = '/js/ammo.js';
}
/*
  The renderer needs a size and the actual canvas we draw on
  needs to be added to the body of the webpage. We also specify
  that the renderer will be computing soft shadows
*/
function initRenderer(){
  renderer = new THREE.WebGLRenderer();
	renderer.setPixelRatio( window.devicePixelRatio );
	renderer.setSize( window.innerWidth, window.innerHeight );
}

function initScene(){
  //scene = new THREE.Scene();
  var scene = new Physijs.Scene();
  scene.background = new THREE.Color( 0xbfd1e5 );
  return scene;
}

function createMainScene(){
  container = document.getElementById( 'container' );
  camera = new THREE.PerspectiveCamera( 60, window.innerWidth / window.innerHeight, 1, 20000 );
  camera.position.x = 20;
	camera.position.y = getY( worldHalfWidth, worldHalfDepth ) * 100 + 100;
  camera.position.z = 100;
	//gameState.camera = camera;

  edgeCam = new THREE.PerspectiveCamera( 60, window.innerWidth / window.innerHeight, 1, 20000 );
  edgeCam.position.x=200;
  edgeCam.position.y=getY( worldHalfWidth, worldHalfDepth ) * 100;
  edgeCam.position.z = 200;

	avatarCam = new THREE.PerspectiveCamera( 60, window.innerWidth / window.innerHeight, 0.1, 1000 );
	avatar = createAvatar();
	avatar.position.y = getY( worldHalfWidth, worldHalfDepth ) * 100 + 100;
	//getY( worldHalfWidth, worldHalfDepth ) * 100 + 100;
	avatarCam.translateY(-4);
	avatarCam.translateZ(3);
	scene.add(avatar);
	gameState.camera = avatarCam;


  var matrix = new THREE.Matrix4();
  //scene = new THREE.Scene();
	//scene.background = new THREE.Color( 0xbfd1e5 );

	var texture = new THREE.TextureLoader().load( '../textures/minecraft/atlas.png' );
	texture.magFilter = THREE.NearestFilter;
	texture.minFilter = THREE.LinearMipMapLinearFilter;

	var pxGeometry = new THREE.PlaneGeometry( 100, 100, 10);
	var material2 = new THREE.MeshLambertMaterial( { color: 0xffffff,  map: texture ,side:THREE.DoubleSide} );
	var pmaterial2 = new Physijs.createMaterial(material2,0.9,0.05);
	//pxGeometry.attributes.uv.array[ 1 ] = 0.5;
	//pxGeometry.attributes.uv.array[ 3 ] = 0.5;
	pxGeometry.rotateY( Math.PI / 2 );
	pxGeometry.translate( 50, 0, 0 );
	var mesh2 = new Physijs.BoxMesh( pxGeometry, pmaterial2,0);
	scene.add( mesh2 );

	var nxGeometry = new THREE.PlaneGeometry( 100, 100, 10);
	var material3 = new THREE.MeshLambertMaterial( { color: 0xffffff,  map: texture ,side:THREE.DoubleSide} );
	var pmaterial3 = new Physijs.createMaterial(material3,0.9,0.05);
	//nxGeometry.attributes.uv.array[ 1 ] = 0.5;
	//nxGeometry.attributes.uv.array[ 3 ] = 0.5;
	nxGeometry.rotateY( - Math.PI / 2 );
	nxGeometry.translate( - 50, 0, 0 );
	var mesh3 = new Physijs.BoxMesh( nxGeometry, pmaterial3,0);
	scene.add( mesh3 );

	var pyGeometry = new THREE.PlaneGeometry( 100, 100, 10);
	var material4 = new THREE.MeshLambertMaterial( { color: 0xffffff,  map: texture ,side:THREE.DoubleSide} );
	var pmaterial4 = new Physijs.createMaterial(material4,0.9,0.05);
	//pyGeometry.attributes.uv.array[ 5 ] = 0.5;
	//pyGeometry.attributes.uv.array[ 7 ] = 0.5;
	pyGeometry.rotateX( - Math.PI / 2 );
	pyGeometry.translate( 0, 50, 0 );
	var mesh4 = new Physijs.PlaneMesh( pyGeometry, pmaterial4, 0);
	scene.add( mesh4 );

	var pzGeometry = new THREE.PlaneGeometry( 100, 100, 10);
	var material5 = new THREE.MeshLambertMaterial( { color: 0xffffff,  map: texture ,side:THREE.DoubleSide} );
	var pmaterial5 = new Physijs.createMaterial(material5,0.9,0.05);
	//pzGeometry.attributes.uv.array[ 1 ] = 0.5;
	//pzGeometry.attributes.uv.array[ 3 ] = 0.5;
	pzGeometry.translate( 0, 0, 50 );
	var mesh5 = new Physijs.BoxMesh( pzGeometry, pmaterial5,0);
	scene.add( mesh5 );

	var nzGeometry = new THREE.PlaneGeometry( 100, 100, 10);
	var material6 = new THREE.MeshLambertMaterial( { color: 0xffffff,  map: texture ,side:THREE.DoubleSide} );
	var pmaterial6 = new Physijs.createMaterial(material6,0.9,0.05);
	//nzGeometry.attributes.uv.array[ 1 ] = 0.5;
	//nzGeometry.attributes.uv.array[ 3 ] = 0.5;
	nzGeometry.rotateY( Math.PI );
	nzGeometry.translate( 0, 0, -50 );
	var mesh6 = new Physijs.BoxMesh( nzGeometry, pmaterial6,0);
	scene.add( mesh6 );
/*
	// BufferGeometry cannot be merged yet.
	var tmpGeometry = new THREE.Geometry();
	var pxTmpGeometry = new THREE.Geometry().fromBufferGeometry( pxGeometry );
	var nxTmpGeometry = new THREE.Geometry().fromBufferGeometry( nxGeometry );
	var pyTmpGeometry = new THREE.Geometry().fromBufferGeometry( pyGeometry );
	var pzTmpGeometry = new THREE.Geometry().fromBufferGeometry( pzGeometry );
	var nzTmpGeometry = new THREE.Geometry().fromBufferGeometry( nzGeometry );
*/
/*
var geometry = new THREE.PlaneGeometry();

	for ( var z = 0; z < worldDepth; z ++ ) {
		for ( var x = 0; x < worldWidth; x ++ ) {
			var h = getY( x, z );
			matrix.makeTranslation(
				x * 100 - worldHalfWidth * 100,
				h * 100,
				z * 100 - worldHalfDepth * 100
			);
			var px = getY( x + 1, z );
			var nx = getY( x - 1, z );
			var pz = getY( x, z + 1 );
			var nz = getY( x, z - 1 );
			geometry.merge( pyGeometry, matrix );
			if ( ( px !== h && px !== h + 1 ) || x === 0 ) {
				geometry.merge( pxGeometry, matrix );
			}
			if ( ( nx !== h && nx !== h + 1 ) || x === worldWidth - 1 ) {
				geometry.merge( nxGeometry, matrix );
			}
			if ( ( pz !== h && pz !== h + 1 ) || z === worldDepth - 1 ) {
				geometry.merge( pzGeometry, matrix );
			}
			if ( ( nz !== h && nz !== h + 1 ) || z === 0 ) {
				geometry.merge( nzGeometry, matrix );
			}
		}
	}

/*
	var geometry = new THREE.BufferGeometry().fromGeometry( tmpGeometry );
	geometry.computeBoundingSphere();
*//*
var texture = new THREE.TextureLoader().load( '../textures/minecraft/atlas.png' );
texture.magFilter = THREE.NearestFilter;
texture.minFilter = THREE.LinearMipMapLinearFilter;
var material = new THREE.MeshLambertMaterial( { map: texture } );
var pmaterial = new Physijs.createMaterial(material,0.9,0);
var mesh = new Physijs.Mesh( geometry, pmaterial, 0);
scene.add( mesh );
*/
/*
	var geometry = tmpGeometry;

	var texture = new THREE.TextureLoader().load( '../textures/minecraft/atlas.png' );
	texture.magFilter = THREE.NearestFilter;
	texture.minFilter = THREE.LinearMipMapLinearFilter;

	var material = new THREE.MeshLambertMaterial( { map: texture } );
	var pmaterial = new Physijs.createMaterial(material,0.9,0);
	var mesh = new Physijs.Mesh( geometry, pmaterial, 0);
	scene.add( mesh );
*/
	var ambientLight = new THREE.AmbientLight( 0xcccccc );
	scene.add( ambientLight );

	var directionalLight = new THREE.DirectionalLight( 0xffffff, 2 );
	directionalLight.position.set( 1, 1, 0.5 ).normalize();
	scene.add( directionalLight );

	container.innerHTML = "";
	container.appendChild( renderer.domElement );
	stats = new Stats();
	//container.appendChild( stats.dom );
	//
	window.addEventListener( 'resize', onWindowResize, false );
  window.addEventListener( 'keydown', keydown, false);
}

function onWindowResize() {
	camera.aspect = window.innerWidth / window.innerHeight;
	camera.updateProjectionMatrix();
	renderer.setSize( window.innerWidth, window.innerHeight );
	controls.handleResize();
}

function createAvatar(){
	//var geometry = new THREE.SphereGeometry( 4, 20, 20);
	var geometry = new THREE.BoxBufferGeometry( 20, 20, 20);
	var material = new THREE.MeshLambertMaterial( { color: 0xffff00} );
	var pmaterial = new Physijs.createMaterial(material,0.9);
	//var mesh = new THREE.Mesh( geometry, material );
	var mesh = new Physijs.BoxMesh( geometry, pmaterial);
	mesh.setDamping(0.1,0.1);
	mesh.castShadow = true;

	avatarCam.position.set(0,4,0);
	avatarCam.lookAt(0,4,10);
	mesh.add(avatarCam);
	return mesh;

}

function generateHeight( width, height ) {
	var data = [], perlin = new ImprovedNoise(),
	size = width * height, quality = 2, z = Math.random() * 100;
	for ( var j = 0; j < 4; j ++ ) {
		if ( j === 0 ) for ( var i = 0; i < size; i ++ ) data[ i ] = 0;
		for ( var i = 0; i < size; i ++ ) {
			var x = i % width, y = ( i / width ) | 0;
			data[ i ] += perlin.noise( x / quality, y / quality, z ) * quality;
		}
		quality *= 4;
	}
	return data;
}

function getY( x, z ) {
	return ( data[ x + z * worldWidth ] * 0.2 ) | 0;
}

function initControls(){
	// here is where we create the eventListeners to respond to operations

		//create a clock for the time-based animation ...
		clock = new THREE.Clock();
		clock.start();

		window.addEventListener( 'keydown', keydown);
		window.addEventListener( 'keyup',   keyup );
}

function keydown(event){
	console.log("Keydown: '"+event.key+"'");
	//console.dir(event);
	// first we handle the "play again" key in the "youwon" scene
	// this is the regular scene
	switch (event.key){
		// change the way the avatar is moving
		case "w": controls.fwd = true;  break;
		case "s": controls.bwd = true; break;
		case "a": controls.left = true; break;
		case "d": controls.right = true; break;
		case "r": controls.up = true; break;
		case "f": controls.down = true; break;
		case "m": controls.speed = 30; break;
		case " ": controls.fly = true;
				console.log("space!!");
				break;
		case "h": controls.reset = true; break;
		case "q": controls.rotateToLeft = true; break;
		case "e": controls.rotateToRight = true; break;


		// switch cameras
		case "1": gameState.camera = camera; break;
		case "2": gameState.camera = avatarCam; break;
		case "3": gameState.camera = edgeCam; break;

		// move the camera around, relative to the avatar
		case "ArrowLeft": avatarCam.translateY(1);break;
		case "ArrowRight": avatarCam.translateY(-1);break;
		case "ArrowUp": avatarCam.translateZ(-1);break;
		case "ArrowDown": avatarCam.translateZ(1);break;

	}

}

function keyup(event){
	//console.log("Keydown:"+event.key);
	//console.dir(event);
	switch (event.key){
		case "w": controls.fwd   = false;  break;
		case "s": controls.bwd   = false; break;
		case "a": controls.left  = false; break;
		case "d": controls.right = false; break;
		case "r": controls.up    = false; break;
		case "f": controls.down  = false; break;
		case "m": controls.speed = 10; break;
		case " ": controls.fly = false; break;
		case "h": controls.reset = false; break;
		case "q": controls.rotateToLeft = false; break;
		case "e": controls.rotateToRight = false; break;
	}
}


function updateAvatar(){
	"change the avatar's linear or angular velocity based on controls state (set by WSAD key presses)"

	var forward = avatar.getWorldDirection();
	var goLeft = avatar.getWorldDirection();

	if (controls.fwd){
		avatar.setLinearVelocity(forward.multiplyScalar(controls.speed));
	} else if (controls.bwd){
		avatar.setLinearVelocity(forward.multiplyScalar(-controls.speed));
	} else {
		var velocity = avatar.getLinearVelocity();
		velocity.x=velocity.z=0;
		avatar.setLinearVelocity(velocity); //stop the xz motion
	}

	if (controls.fly){
		avatar.setLinearVelocity(new THREE.Vector3(0,controls.speed,0));
	}

	if (controls.left){
		avatar.setAngularVelocity(new THREE.Vector3(0,controls.speed*0.1,0));
	} else if (controls.right){
		avatar.setAngularVelocity(new THREE.Vector3(0,-controls.speed*0.1,0));
	}


	if(controls.rotateToLeft){
		avatarCam.rotateY(0.01);
	}else if(controls.rotateToRight){
		avatarCam.rotateY(-0.01);
	}


	if (controls.reset){
		avatar.__dirtyPosition = true;
		avatar.position.set(40,10,40);
	}

}





function animate() {
	//requestAnimationFrame( animate );
	//render();
	stats.update();
	updateAvatar();

	requestAnimationFrame( animate );

	switch(gameState.scene) {

		case "main":
			edgeCam.lookAt(avatar.position);
			scene.simulate();
			if (gameState.camera!= 'none'){
				renderer.render( scene, gameState.camera );
			}
			break;

		default:
			console.log("don't know the scene "+gameState.scene);
}

	function render() {
		//controls.update( clock.getDelta() );
		renderer.render( scene, camera );
	}
}
